﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnumStringAttribute : PropertyAttribute
{
    public string[] NeedList;
}
