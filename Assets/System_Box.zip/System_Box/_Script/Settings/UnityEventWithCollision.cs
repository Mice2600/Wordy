﻿

using UnityEngine;
using UnityEngine.Events;

namespace SystemBox
{
    [System.Serializable]
    public class UnityEventWithCollision : UnityEvent<Collision> { }
}

