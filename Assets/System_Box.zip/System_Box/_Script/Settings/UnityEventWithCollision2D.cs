﻿
using UnityEngine;
using UnityEngine.Events;

namespace SystemBox
{
    [System.Serializable]
    public class UnityEventWithCollision2D : UnityEvent<Collision2D> { }
}

