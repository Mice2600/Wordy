﻿
using UnityEngine;
using UnityEngine.Events;

namespace SystemBox
{
    [System.Serializable]
    public class UnityEventWithVector3 : UnityEvent<Vector3> { }
}

