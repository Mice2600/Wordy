﻿using UnityEngine;
using UnityEngine.Events;

namespace SystemBox
{
    [System.Serializable]
    public class UnityEventWithString : UnityEvent<string> { }
}

