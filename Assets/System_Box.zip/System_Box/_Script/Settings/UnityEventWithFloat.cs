﻿
using UnityEngine;
using UnityEngine.Events;

namespace SystemBox
{
    [System.Serializable]
    public class UnityEventWithFloat : UnityEvent<float> { }
}
