namespace ProjectSettings
{
    public class ProjectSettingsTabelResurse : TabelRessursSettings<ProjectSettings> { }
}